ATIQ TOOLS — PDF PASSWORD UNLOCKER (PHASE 1)

IMPORTANT:
- This kit adds a browser-side PDF unlocker that requires the CURRENT, KNOWN password.
- It does NOT recover forgotten passwords or perform automatic guessing.
- The PDF is processed in the visitor's browser using pdfstudio/QPDF WebAssembly.
- The tool source is in tools/pdf-password-recovery-src/.
- The published output is built into tools/pdf-password-recovery/ by GitHub Actions.

GITHUB WEBSITE PAR COPY/PASTE STEPS:
1) Open https://github.com/atiq-se-dev/my-Portfolio
2) Open tools/ and create a folder named pdf-password-recovery-src.
3) In that folder create package.json, vite.config.js, index.html.
4) Create src folder inside pdf-password-recovery-src, then create main.js and style.css inside src.
5) Copy the matching files from this kit into those paths.
6) Open .github/workflows/static.yml and replace its complete contents with the static.yml from this kit.
   Do not create a second workflow with the same purpose; replace the existing static.yml.
7) Commit changes to the main branch.
8) Open the repository Actions tab. Wait for “Deploy static content to Pages” to finish successfully.
9) Open https://atiq-se.com/tools/pdf-password-recovery/

TESTING:
- Use a PDF you own and set a password on a copy, then test with that password.
- Test an incorrect password: the page should show an error and not offer a download.
- Test a non-PDF file: it should be rejected.
- After success, download the output and open it to confirm it is no longer asking for a password.
- If Actions fails, open the failed run and copy the first red error message so it can be diagnosed.

NOTE:
The source folder is intentionally separate from the published output folder. Do not create/edit files manually inside tools/pdf-password-recovery/; GitHub Actions builds that folder during deployment.
